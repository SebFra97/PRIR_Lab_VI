package Lab5_ForkJoinPool;

public interface Sort {
    void sort(int[] tab);
}
