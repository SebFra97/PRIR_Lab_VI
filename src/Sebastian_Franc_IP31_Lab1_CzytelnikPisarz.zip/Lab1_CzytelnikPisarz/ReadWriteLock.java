package Lab1_CzytelnikPisarz;

public class ReadWriteLock {
    public void registerReader(Thread t) {
    }
}
