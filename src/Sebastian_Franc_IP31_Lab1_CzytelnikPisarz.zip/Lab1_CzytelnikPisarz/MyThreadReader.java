package Lab1_CzytelnikPisarz;

public class MyThreadReader {

    ReadWriteLock lock;
    String filename;

    public MyThreadReader(ReadWriteLock lock, String fileName) {
        this.lock = lock;
        this.filename = fileName;
    }
}
