package Lab1_CzytelnikPisarz;

public interface Czytelnia {
    void chceCzytac();
    void koniecCzytania();
    void chcePisac();
    void koniecPisania();
}
