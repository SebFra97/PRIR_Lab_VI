package Lab1_CzytelnikPisarz;

public class MyThreadWriter {

    ReadWriteLock lock;
    String filename;

    public MyThreadWriter(ReadWriteLock lock, String fileName) {
        this.lock = lock;
        this.filename = fileName;
    }
}
