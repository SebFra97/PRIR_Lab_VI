package Lab6_RMI;

public interface Zadanie {
    public void licz();
    public Object getWynik();
}
