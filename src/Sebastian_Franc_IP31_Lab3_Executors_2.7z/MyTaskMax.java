package Lab3_Executors;

import java.io.File;
import java.util.Scanner;
import java.util.concurrent.Callable;

public class MyTaskMax implements Callable {

    String fileName;
    double max  = 0;

    public MyTaskMax(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public Object call() throws Exception {

        File file = new File(fileName);
        Scanner scan = new Scanner(file);

        while (scan.hasNext()) {
            double temp = Double.parseDouble(scan.next());

            if (temp > max) {
                max = temp;
            }
        }
        System.out.println("Wartość chwilowa zadania "+ Thread.currentThread().getId() + " : " + max);
        return max;
    }
}
