package Lab3_Executors;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.*;

public class main2 {

    public static void main(String[] args) {

        List<String> srcFiles =  List.of("plikA.txt","plikB.txt","plikC.txt","plikD.txt","plikE.txt","plikF.txt","plikG.txt");
        List<Future<String>> futureLista = new ArrayList<>(List.of());

        double suma = 0.0;

        ExecutorService executor = Executors.newFixedThreadPool(3);

        for (int i = 0; i<srcFiles.size(); i++)
        {
            MyTaskMax maxTask = new MyTaskMax(srcFiles.get(i));
            System.out.println("Dodanie Zadania  # " + i);
            futureLista.add(executor.submit(maxTask));
        }

        executor.shutdown();

        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);

            for (Future rezultat: futureLista) {
                suma += (double)rezultat.get();
            }
            System.out.println("Suma maksymalnej wartości  :" + suma );

        } catch (InterruptedException | ExecutionException e) {}

    }
}
