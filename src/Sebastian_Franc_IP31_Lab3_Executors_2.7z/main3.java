package Lab3_Executors;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class main3 {
    public static void main(String[] args) throws InterruptedException {

        List<String> srcFiles =  List.of("plikA.txt","plikB.txt","plikC.txt","plikD.txt","plikE.txt","plikF.txt","plikG.txt");
        List<Callable<Double>> listaZadan =  new ArrayList<>(List.of());
        List<Future<Double>> rezultaty = new ArrayList<>(List.of());

        double suma = 0.0;

        ExecutorService executor = Executors.newFixedThreadPool(3);

        for(int i = 0; i < srcFiles.size(); i++) {

            MyTaskMax maxTask = new MyTaskMax(srcFiles.get(i));
            System.out.println("Dodanie Zadania  # " + i);
            listaZadan.add(maxTask);
        }

        rezultaty = executor.invokeAll(listaZadan);

        executor.shutdown();

        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);

            for (Future rezultat: rezultaty) {
                suma += (double)rezultat.get();
            }
            System.out.println("Suma maksymalnej wartości  :" + suma );

        } catch (InterruptedException | ExecutionException e) {}

    }
}
