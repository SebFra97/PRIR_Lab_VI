package Lab2_JavaCollections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.lang.Thread.sleep;

public class main {
    public static void main(String[] args) throws InterruptedException {

        // List<Integer> lista = new ArrayList<Integer>(); // ZAD 1
        List<Integer> lista;
        lista = new ArrayList<>();
        lista = Collections.synchronizedList(lista);


        MyProducentThread producent = new MyProducentThread(lista);
        MyConsumentThread konsument = new MyConsumentThread(lista);
        MySumThread sumThread = new MySumThread(lista);

        producent.start();
        konsument.start();
        sumThread.start();

        Thread.sleep(30_000);

        producent.interrupt();
        konsument.interrupt();
        sumThread.interrupt();

    }
}
