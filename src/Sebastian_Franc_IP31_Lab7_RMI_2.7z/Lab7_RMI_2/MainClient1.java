package Lab7_RMI_2;

public class MainClient1 {
    public static void main(String[] args) {
        Client client = new Client("Jacek","ZAQ12wsx");
        client.start();
    }
}
