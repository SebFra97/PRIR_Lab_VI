package Lab7_RMI_2;

public class MainClient2 {
    public static void main(String[] args) {
        Client client = new Client("Ania","qwerty");
        client.start();
    }
}

